import Foundation
import CoreGraphics
import ApplicationServices
import Darwin
import Dispatch

// V6: 90-degree rotation only for the subtype observed for the built-in trackpad in V5.
// Mouse subtype 0 retains original direction. This is NOT a physical-device-ID test.
// V4 cursor warp echo correction is preserved; macOS build/runtime testing required.
private var clockwise = true
private var trackpadSubtype: Int64 = 3
private var desiredPosition = CGPoint.zero
private var pendingWarp = CGPoint.zero
private var counter = 0
private var trackpadCount = 0
private var mouseCount = 0
private var otherCount = 0
private var detached = false
private var stopped = false
private var tapRef: CFMachPort?

private func restore() {
    if stopped { return }
    stopped = true
    if let tap = tapRef { CGEvent.tapEnable(tap: tap, enable: false) }
    if detached {
        let err = CGAssociateMouseAndMouseCursorPosition(1)
        print("RESTORE mouse association status=\(err.rawValue)")
        detached = false
    }
    print("SUMMARY total=\(counter) trackpad-subtype=\(trackpadCount) mouse-subtype-0=\(mouseCount) other=\(otherCount)")
    fflush(stdout)
}

private func callback(_ proxy: CGEventTapProxy, _ type: CGEventType,
                      _ event: CGEvent, _ info: UnsafeMutableRawPointer?) -> Unmanaged<CGEvent>? {
    if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
        fputs("WARNING event tap disabled, restoring cursor association.\n", stderr)
        restore()
        CFRunLoopStop(CFRunLoopGetMain())
        return Unmanaged.passUnretained(event)
    }
    guard !stopped else { return Unmanaged.passUnretained(event) }
    guard type == .mouseMoved || type == .leftMouseDragged ||
          type == .rightMouseDragged || type == .otherMouseDragged else {
        return Unmanaged.passUnretained(event)
    }

    let subtype = event.getIntegerValueField(.mouseEventSubtype)
    let rawX = Double(event.getIntegerValueField(.mouseEventDeltaX))
    let rawY = Double(event.getIntegerValueField(.mouseEventDeltaY))
    let echo = pendingWarp
    pendingWarp = .zero
    let dx = rawX - Double(echo.x)
    let dy = rawY - Double(echo.y)

    // Device-specific transformation, applied to movement after warp echo subtraction.
    let outX: Double
    let outY: Double
    let label: String
    if subtype == trackpadSubtype {
        let s: Double = clockwise ? 1 : -1
        outX = -s * dy
        outY = s * dx
        trackpadCount += 1
        label = "TRACKPAD"
    } else if subtype == 0 {
        outX = dx
        outY = dy
        mouseCount += 1
        label = "MOUSE"
    } else {
        // Unknown source: preserve movement without rotation.
        outX = dx
        outY = dy
        otherCount += 1
        label = "UNKNOWN"
    }

    let oldPosition = desiredPosition
    let target = CGPoint(x: oldPosition.x + outX, y: oldPosition.y + outY)
    if outX != 0 || outY != 0 {
        let error = CGWarpMouseCursorPosition(target)
        if error != .success {
            fputs("ERROR cursor warp failed: \(error.rawValue)\n", stderr)
            restore()
            CFRunLoopStop(CFRunLoopGetMain())
            return nil
        }
        pendingWarp = CGPoint(x: outX, y: outY)
        desiredPosition = target
    }
    counter += 1
    if counter <= 25 || counter % 100 == 0 {
        print(String(format: "%d %@ sub=%lld raw=(%.0f,%.0f) echo=(%.0f,%.0f) corrected=(%.0f,%.0f) out=(%.0f,%.0f)",
                     counter, label, subtype, rawX, rawY, echo.x, echo.y, dx, dy, outX, outY))
        fflush(stdout)
    }
    // V4 technique: suppress normal movement event for BOTH inputs, because cursor
    // association was disabled globally. Mouse deltas are reproduced without rotation.
    // Drag event forwarding / app-level drag semantics still need separate tests.
    return nil
}

let args = Set(CommandLine.arguments.dropFirst())
if args.contains("--help") {
    print("Usage: ./TrackpadRotate [--clockwise | --counterclockwise] [--subtype=3]")
    print("V6 diagnostic: rotates matched subtype only; other source movement is unrotated.")
    exit(0)
}
clockwise = !args.contains("--counterclockwise")
if let override = args.first(where: { $0.hasPrefix("--subtype=") }) {
    guard let parsed = Int64(override.dropFirst("--subtype=".count)), parsed != 0 else {
        fputs("Invalid subtype; must be nonzero integer.\n", stderr)
        exit(1)
    }
    trackpadSubtype = parsed
}
let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
guard AXIsProcessTrustedWithOptions(opts) else {
    fputs("Accessibility permission required for Terminal.\n", stderr)
    exit(2)
}
let types: [CGEventType] = [.mouseMoved, .leftMouseDragged, .rightMouseDragged, .otherMouseDragged]
let mask = types.reduce(CGEventMask(0)) { $0 | (CGEventMask(1) << $1.rawValue) }
guard let tap = CGEvent.tapCreate(tap: .cgSessionEventTap,
                                  place: .headInsertEventTap,
                                  options: .defaultTap,
                                  eventsOfInterest: mask,
                                  callback: callback,
                                  userInfo: nil) else {
    fputs("Failed to create event tap; check permissions.\n", stderr)
    exit(3)
}
tapRef = tap
guard let source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0) else {
    fputs("Failed to create runloop source.\n", stderr)
    exit(4)
}
CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
CGEvent.tapEnable(tap: tap, enable: true)
desiredPosition = CGEvent(source: nil)?.location ?? .zero
let err = CGAssociateMouseAndMouseCursorPosition(0)
guard err == .success else {
    print("Cannot detach cursor: \(err.rawValue)")
    restore()
    exit(5)
}
detached = true
signal(SIGINT, SIG_IGN)
signal(SIGTERM, SIG_IGN)
let sigint = DispatchSource.makeSignalSource(signal: SIGINT, queue: .main)
let sigterm = DispatchSource.makeSignalSource(signal: SIGTERM, queue: .main)
sigint.setEventHandler { restore(); CFRunLoopStop(CFRunLoopGetMain()) }
sigterm.setEventHandler { restore(); CFRunLoopStop(CFRunLoopGetMain()) }
sigint.resume()
sigterm.resume()
let timer = Timer(timeInterval: 20, repeats: false) { _ in
    print("20-second test finished")
    restore()
    CFRunLoopStop(CFRunLoopGetMain())
}
RunLoop.main.add(timer, forMode: .common)
print("V6 test: trackpadSubtype=\(trackpadSubtype) clockwise=\(clockwise) max=20s")
print("0-6s trackpad; 6-12s mouse; 12-20s both. Press Ctrl+C to stop.")
fflush(stdout)
CFRunLoopRun()
restore()
CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes)
sigint.cancel()
sigterm.cancel()
