# V6: トラックパッドとマウスの同時利用試験

V4で確認された90度回転・warpEcho補正を維持し、V5で実測された subtype により移動を振り分けます。

- `subtype=3`: 90度回転（V5でMacBook Air内蔵トラックパッドに対応した実測値）
- `subtype=0`: 回転せず移動（V5で外付けマウスに対応した実測値）
- その他のsubtype: 回転しない

**重要**: これは厳密な「内蔵機器識別」ではありません。外付けMagic Trackpadも`3`を返す可能性があり、未検証です。

## 実行

macOSターミナルで展開フォルダに移動してから:

```bash
swiftc -framework ApplicationServices -framework CoreGraphics TrackpadRotate.swift -o TrackpadRotate
./TrackpadRotate --clockwise | tee V6-log.txt
```

逆方向は `./TrackpadRotate --counterclockwise`。

### 試験

- 0～6秒: 内蔵トラックパッドのみを移動
- 6～12秒: 外付けマウスのみを移動
- 12～20秒: 両方を同時に移動

画面中央で小さく操作してください。20秒で自動終了、Ctrl+Cでも終了します。通常のマウス移動に戻ることを確認してください。

### 注意

- V6は実機未検証。コンパイル・動作の両方を確認してください。
- `CGAssociateMouseAndMouseCursorPosition`を使用するため、実行中は全ポインティングデバイスの自動カーソル移動が無効になり、スクリプトで再現します。
- クリックやドラッグ、スクロール、ジェスチャーの完成動作は未検証です。V6は移動方向のみの試験です。
- イベントタップが失効、アプリが強制終了、OSが異常状態となった場合に復元処理が実行されない可能性があります。試験中はキーボード操作可能な状態を維持してください。
- 通常カーソル操作に戻らない場合、別ターミナルから `swift -e 'import CoreGraphics; print(CGAssociateMouseAndMouseCursorPosition(1))'` を試してください（実機未検証の復旧コマンド）。
- 他のポインター補助アプリや仮想入力デバイスのsubtypeは未検証です。

## ログ

ログに表示される `TRACKPAD`, `MOUSE`, `UNKNOWN` はサブタイプによる分類名であり、デバイスIDではありません。

## 今後

動作成功後、クリック・ドラッグを扱い、別の実装で内蔵トラックパッドの厳密な識別（IOHID系）が可能か調べます。
