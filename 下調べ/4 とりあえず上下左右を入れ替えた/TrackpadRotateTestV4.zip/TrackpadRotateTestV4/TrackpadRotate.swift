import Foundation
import CoreGraphics
import ApplicationServices
import Darwin
import Dispatch

// V4 diagnostic: remove the delta introduced by the previous cursor warp.
// Applies to ALL pointing devices. Requires Accessibility access.
// The behavior on macOS 27 has NOT been verified.

private var clockwise = true
private var compensate = true
private var desiredPosition = CGPoint.zero
private var pendingWarp = CGPoint.zero
private var eventCount = 0
private var detached = false
private var tapRef: CFMachPort?

private func restore() {
    if detached {
        let err = CGAssociateMouseAndMouseCursorPosition(1)
        print("Restored mouse association: \(err.rawValue)")
        detached = false
    }
    if let tap = tapRef { CGEvent.tapEnable(tap: tap, enable: false) }
    fflush(stdout)
}

private func callback(_ proxy: CGEventTapProxy, _ type: CGEventType,
                      _ event: CGEvent, _ userInfo: UnsafeMutableRawPointer?) -> Unmanaged<CGEvent>? {
    if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
        fputs("Event tap disabled; restoring.\n", stderr)
        restore()
        CFRunLoopStop(CFRunLoopGetMain())
        return Unmanaged.passUnretained(event)
    }
    guard type == .mouseMoved || type == .leftMouseDragged ||
          type == .rightMouseDragged || type == .otherMouseDragged else {
        return Unmanaged.passUnretained(event)
    }

    let rawX = Double(event.getIntegerValueField(.mouseEventDeltaX))
    let rawY = Double(event.getIntegerValueField(.mouseEventDeltaY))
    let correction = pendingWarp
    pendingWarp = .zero
    let dx = rawX - (compensate ? Double(correction.x) : 0)
    let dy = rawY - (compensate ? Double(correction.y) : 0)

    // Convert +x right, +y down; clockwise rotation of the *physical device*.
    let s: Double = clockwise ? 1 : -1
    let rx = -s * dy
    let ry = s * dx
    let from = desiredPosition
    let target = CGPoint(x: from.x + rx, y: from.y + ry)
    let result = CGWarpMouseCursorPosition(target)
    if result != .success {
        fputs("Cursor warp failed: \(result.rawValue)\n", stderr)
        restore()
        CFRunLoopStop(CFRunLoopGetMain())
        return nil
    }
    // Warp's displacement can be included in the next input event's delta.
    // Subtract it ONCE from that next event. This is a hypothesis under test.
    pendingWarp = CGPoint(x: target.x - from.x, y: target.y - from.y)
    desiredPosition = target
    eventCount += 1
    if eventCount <= 20 || eventCount % 50 == 0 {
        print(String(format: "%d raw=(%.0f,%.0f) warpEcho=(%.0f,%.0f) corrected=(%.0f,%.0f) rotated=(%.0f,%.0f)",
                     eventCount, rawX, rawY, correction.x, correction.y, dx, dy, rx, ry))
        fflush(stdout)
    }
    // Drop original movement event; no original move should reach apps.
    return nil
}

let args = Set(CommandLine.arguments.dropFirst())
if args.contains("--help") {
    print("Usage: ./TrackpadRotate [--clockwise | --counterclockwise] [--no-compensate]")
    exit(0)
}
clockwise = !args.contains("--counterclockwise")
compensate = !args.contains("--no-compensate")
let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
guard AXIsProcessTrustedWithOptions(options) else {
    fputs("Accessibility permission required for Terminal.\n", stderr)
    exit(2)
}
let types: [CGEventType] = [.mouseMoved, .leftMouseDragged, .rightMouseDragged, .otherMouseDragged]
let mask = types.reduce(CGEventMask(0)) { $0 | (CGEventMask(1) << $1.rawValue) }
guard let tap = CGEvent.tapCreate(tap: .cgSessionEventTap,
                                  place: .headInsertEventTap,
                                  options: .defaultTap,
                                  eventsOfInterest: mask,
                                  callback: callback,
                                  userInfo: nil) else {
    fputs("Cannot create event tap; check privacy permissions.\n", stderr)
    exit(3)
}
tapRef = tap
guard let source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0) else {
    fputs("Cannot create event tap runloop source.\n", stderr)
    exit(4)
}
CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
CGEvent.tapEnable(tap: tap, enable: true)
desiredPosition = CGEvent(source: nil)?.location ?? .zero
let detachErr = CGAssociateMouseAndMouseCursorPosition(0)
guard detachErr == .success else {
    print("Cannot detach mouse: \(detachErr.rawValue)")
    restore()
    exit(5)
}
detached = true
signal(SIGINT, SIG_IGN)
signal(SIGTERM, SIG_IGN)
let sigint = DispatchSource.makeSignalSource(signal: SIGINT, queue: .main)
let sigterm = DispatchSource.makeSignalSource(signal: SIGTERM, queue: .main)
sigint.setEventHandler { restore(); CFRunLoopStop(CFRunLoopGetMain()) }
sigterm.setEventHandler { restore(); CFRunLoopStop(CFRunLoopGetMain()) }
sigint.resume()
sigterm.resume()
let timeout = Timer(timeInterval: 15, repeats: false) { _ in
    print("15-second test completed.")
    restore()
    CFRunLoopStop(CFRunLoopGetMain())
}
RunLoop.main.add(timeout, forMode: .common)
print("V4 diagnostic: compensation=\(compensate), clockwise=\(clockwise); 15s maximum")
print("Test only with small finger movements near screen center. Ctrl+C to stop.")
fflush(stdout)
CFRunLoopRun()
restore()
CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes)
sigint.cancel()
sigterm.cancel()
