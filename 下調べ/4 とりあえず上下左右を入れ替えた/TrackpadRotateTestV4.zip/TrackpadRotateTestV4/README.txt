Trackpad rotation experiment V4 - NOT tested on macOS hardware.

Build:
  swiftc -framework ApplicationServices -framework CoreGraphics TrackpadRotate.swift -o TrackpadRotate

Run:
  ./TrackpadRotate --clockwise
  ./TrackpadRotate --counterclockwise

Diagnostics (optional comparison to V3):
  ./TrackpadRotate --clockwise --no-compensate

Move the cursor near the center before running. Move a finger gently in one direction.
The test restores cursor association after 15 seconds or Ctrl+C.
It temporarily affects ALL pointing devices, not just the built-in trackpad.
WARNING: force quitting may skip cleanup. Avoid force quit.

Recovery if needed:
  swift -e 'import CoreGraphics; print(CGAssociateMouseAndMouseCursorPosition(1))'

Please report: cursor direction, whether it is smooth, and 10-20 lines of raw/warpEcho/corrected logs.

The program subtracts the previous warp displacement from the next event's delta. This
is experimental: the warp contribution may not map one-for-one on all macOS versions.
No SIP changes or kernel extensions required.
