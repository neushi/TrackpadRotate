import Foundation
import CoreGraphics
import AppKit
import ApplicationServices
import Darwin
import Dispatch

// V5: read-only origin discriminator probe.
// This program DOES NOT rotate, warp, suppress, or generate mouse events.
// It checks whether the CGEvent stream preserves AppKit's touch/mouse subtype.

private var counter = 0
private var counts: [String: Int] = [:]
private var logLines: [String] = []
private var eventTap: CFMachPort?
private var lastSample = Date.distantPast
private let start = Date()
private let totalSeconds: TimeInterval = 30

private func log(_ line: String) {
    print(line)
    logLines.append(line)
    fflush(stdout)
}

private func labelFor(_ type: CGEventType) -> String {
    switch type {
    case .mouseMoved: return "move"
    case .leftMouseDragged: return "leftDrag"
    case .rightMouseDragged: return "rightDrag"
    case .otherMouseDragged: return "otherDrag"
    default: return "other"
    }
}

private func callback(_ proxy: CGEventTapProxy, _ type: CGEventType,
                      _ event: CGEvent, _ userInfo: UnsafeMutableRawPointer?) -> Unmanaged<CGEvent>? {
    if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
        log("WARNING: event tap disabled (\(type.rawValue)); no further input will be recorded.")
        if let tap = eventTap { CGEvent.tapEnable(tap: tap, enable: true) }
        return Unmanaged.passUnretained(event)
    }
    guard type == .mouseMoved || type == .leftMouseDragged || type == .rightMouseDragged || type == .otherMouseDragged else {
        return Unmanaged.passUnretained(event)
    }

    // Never change the incoming event. This is a listen-only event tap.
    counter += 1
    let cgSubtype = event.getIntegerValueField(.mouseEventSubtype)
    let nsSubtype = NSEvent(cgEvent: event).map { String($0.subtype.rawValue) } ?? "nil"
    let pair = "CG=\(cgSubtype),NS=\(nsSubtype)"
    counts[pair, default: 0] += 1

    // Periodically capture individual events to compare movement from each device.
    // All counters are included in the summary, even when we don't print individual lines.
    let now = Date()
    if now.timeIntervalSince(lastSample) >= 0.075 && logLines.count < 320 {
        lastSample = now
        let t = now.timeIntervalSince(start)
        let dx = event.getIntegerValueField(.mouseEventDeltaX)
        let dy = event.getIntegerValueField(.mouseEventDeltaY)
        let line = String(format: "%6.2f  %@  dx=%4lld dy=%4lld  CGsub=%lld NSsub=%@",
                          t, labelFor(type), dx, dy, cgSubtype, nsSubtype)
        log(line)
    }
    return Unmanaged.passUnretained(event)
}

let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
guard AXIsProcessTrustedWithOptions(opts) else {
    fputs("Terminal needs Accessibility permission (System Settings > Privacy & Security > Accessibility).\n", stderr)
    exit(2)
}

let types: [CGEventType] = [.mouseMoved, .leftMouseDragged, .rightMouseDragged, .otherMouseDragged]
let mask = types.reduce(CGEventMask(0)) { $0 | (CGEventMask(1) << $1.rawValue) }
guard let tap = CGEvent.tapCreate(tap: .cgSessionEventTap,
                                  place: .headInsertEventTap,
                                  options: .listenOnly,
                                  eventsOfInterest: mask,
                                  callback: callback,
                                  userInfo: nil) else {
    fputs("Could not create event tap. Check Privacy & Security permissions.\n", stderr)
    exit(3)
}
eventTap = tap
guard let source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0) else {
    fputs("Could not create event tap source.\n", stderr)
    exit(4)
}
CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
CGEvent.tapEnable(tap: tap, enable: true)

signal(SIGINT, SIG_IGN)
let stopSignal = DispatchSource.makeSignalSource(signal: SIGINT, queue: .main)
stopSignal.setEventHandler { CFRunLoopStop(CFRunLoopGetMain()) }
stopSignal.resume()

log("V5 input-source diagnostic. Read-only; no pointer rotation. Test duration: 30 seconds.")
log("0-10 s: trackpad ONLY | 10-20 s: mouse ONLY | 20-30 s: BOTH simultaneously")
log("Elapsed   event      movement        CG subtype   NS subtype")
let timer = Timer(timeInterval: totalSeconds, repeats: false) { _ in CFRunLoopStop(CFRunLoopGetMain()) }
RunLoop.main.add(timer, forMode: .common)
CFRunLoopRun()

CGEvent.tapEnable(tap: tap, enable: false)
CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes)
stopSignal.cancel()
log("--- Summary: \(counter) total movement/drag events ---")
for k in counts.keys.sorted() { log("\(k): \(counts[k] ?? 0) events") }
log("Interpretation: Compare CGsub and NSsub across the three 10-second phases.")
log("A distinct subtype that appears ONLY for trackpad movement is a candidate, not yet proof of device-level reliability.")
log("If both devices yield the same values, this event stream alone cannot reliably distinguish them.")
