# V5 — trackpad / mouse simultaneous-identification diagnostic

This test does **not** rotate the pointer. V4 remains the validated rotation baseline.
V5 runs a **read-only CGEventTap**, and records both `CGEvent.mouseEventSubtype` and the `NSEvent.subtype` produced by `NSEvent(cgEvent:)`.

## Build

```sh
swiftc -framework AppKit -framework ApplicationServices -framework CoreGraphics TrackpadSourceProbe.swift -o TrackpadSourceProbe
```

## Run

```sh
./TrackpadSourceProbe | tee V5-log.txt
```

Move the pointer for **30 seconds**, following the elapsed time printed at the beginning:
- 0–10 seconds: **built-in trackpad only**
- 10–20 seconds: **external mouse only**
- 20–30 seconds: **both devices at the same time**

The program ends after 30 seconds. Control-C also ends it. Share the log, including the `Summary` section.

## Interpreting the results

- Different subtype values for each device: candidate source identification, including simultaneous operation, but **not yet proven** until the distributions and exceptions are checked.
- Identical subtype values: cannot identify origin from these two fields alone; further investigation with HID per-device reports is needed.
- Touch subtype support described in an archived Apple AppKit guide does not guarantee that modern macOS preserves it when converting a CGEvent to NSEvent.

This probe does not modify cursor position, input association, any device setting, or SIP. It requires no kernel extension.

**Status:** source checked and packaged; no macOS compilation or runtime test performed by the author.
